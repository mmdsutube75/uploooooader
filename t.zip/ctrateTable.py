from uploader import specialDb

specialDb.createTable()