
# -------- bot must be admin in all of channels these channel
channelsLink = {
    # channel link   ,   chat_id
    "https://t.me/ganjnabi" : -1002031822344 ,
    
    # "https://t.me/testMOhammad23" : -1002092989233,
    # "https://t.me/+4j_3BQ0u0WRmZTc0" : -1001983743108,
}
# created by @abdollahi4730
